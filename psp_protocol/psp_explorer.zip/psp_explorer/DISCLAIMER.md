# DISCLAIMER

## PSP Explorer - Read-Only Visualization Tool

### Purpose

PSP Explorer is a **read-only** visualization interface for the PSP Protocol (Proof Of Service Protocol). It provides public access to view protocol data in an Etherscan-style format.

### What This Tool Does

- Displays PoServ certificates (Proof of Service Validations)
- Shows PropertyNFT records and their service history
- Lists workers and their completed services
- Presents protocol statistics and token emission data
- Provides search functionality across public data

### What This Tool Does NOT Do

1. **No Token Emission**: This explorer cannot and does not emit PSP tokens
2. **No Data Modification**: All operations are read-only queries
3. **No Commercial Functions**: No payments, subscriptions, or monetization
4. **No Authentication**: No user accounts or login required for viewing
5. **No Business Logic**: No service matching, booking, or scheduling

### Data Accuracy

The data displayed in this explorer is queried directly from the PSP Protocol database. While we strive for accuracy:

- Data reflects the current state of the protocol
- Historical data is immutable and verifiable via hash
- Statistics are calculated in real-time from protocol records

### No Warranties

This software is provided "AS IS" without warranty of any kind. The developers and operators of this explorer:

- Make no guarantees about data accuracy
- Are not responsible for decisions made based on displayed data
- Do not endorse or validate any specific workers or properties

### Open Source

PSP Explorer is open source under the Apache License 2.0. You are free to:

- Use the code for any purpose
- Modify and distribute
- Create derivative works

### Contact

For questions about the PSP Protocol, please refer to the official documentation.

---

**Last Updated**: January 2026

**Version**: 1.0.0
