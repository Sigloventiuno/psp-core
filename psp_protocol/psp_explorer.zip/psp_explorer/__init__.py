# Copyright 2025 Proof Of Service Protocol
# Licensed under the Apache License, Version 2.0
# See LICENSE file for details.

"""
PSP Explorer - Public Ledger Viewer
====================================

Read-only visualization of PSP Protocol data.

This module provides:
- Certificate viewing and search
- Property (NFT) browsing
- Worker statistics
- Token emission history
- Protocol statistics

IMPORTANT: PSP Explorer is read-only.
It does not emit tokens, does not modify data, and has no commercial features.
"""

from flask import Blueprint

explorer_bp = Blueprint(
    'psp_explorer',
    __name__,
    template_folder='templates',
    static_folder='static',
    url_prefix='/explorer'
)

from . import routes

__version__ = "1.0.0"
