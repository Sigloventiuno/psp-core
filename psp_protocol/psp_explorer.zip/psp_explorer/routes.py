# Copyright 2025 Proof Of Service Protocol
# Licensed under the Apache License, Version 2.0
# See LICENSE file for details.

"""
PSP Explorer Routes
===================

Read-only routes for viewing PSP Protocol data.
Etherscan-style public blockchain explorer.

DISCLAIMER: This explorer is read-only.
It does not emit PSV certificates, modify data, or perform any writes.
"""

from flask import render_template, request, abort
from psp_explorer import explorer_bp
from psp_core import GREEK_WALLETS, TOTAL_PSP_PER_TRANSACTION, get_distribution_summary
import logging

logger = logging.getLogger(__name__)


@explorer_bp.route('/')
def index():
    """PSP Explorer Homepage - Protocol overview"""
    try:
        from app import db
        from models import PoServValidation, PropertyNFT, PropertyCertificate, PropertyLocation
        from sqlalchemy.orm import joinedload
        from sqlalchemy import func
        
        total_certificates = PoServValidation.query.count()
        total_psp_emitted = total_certificates * TOTAL_PSP_PER_TRANSACTION
        
        total_workers = db.session.query(
            func.count(func.distinct(PoServValidation.tecnico_id))
        ).filter(PoServValidation.tecnico_id.isnot(None)).scalar() or 0
        
        total_properties = PropertyNFT.query.count()
        
        recent_certificates = PoServValidation.query.options(
            joinedload(PoServValidation.tecnico),
            joinedload(PoServValidation.property_links).joinedload(PropertyCertificate.property_nft).joinedload(PropertyNFT.property_location)
        ).order_by(
            PoServValidation.fecha_validacion.desc()
        ).all()
        
    except Exception as e:
        logger.error(f"Explorer index error: {e}")
        total_certificates = 0
        total_psp_emitted = 0
        total_workers = 0
        total_properties = 0
        recent_certificates = []
    
    return render_template(
        'explorer/index.html',
        total_certificates=total_certificates,
        total_psp_emitted=total_psp_emitted,
        total_workers=total_workers,
        total_properties=total_properties,
        recent_certificates=recent_certificates
    )


@explorer_bp.route('/certificados')
def certificados():
    """List all PoServ certificates with pagination"""
    try:
        from models import PoServValidation
        
        page = request.args.get('page', 1, type=int)
        per_page = 20
        search = request.args.get('search', '')
        
        query = PoServValidation.query.order_by(
            PoServValidation.fecha_validacion.desc()
        )
        
        if search:
            query = query.filter(
                (PoServValidation.hash_certificado.ilike(f'%{search}%')) |
                (PoServValidation.codigo_validacion.ilike(f'%{search}%'))
            )
        
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        certificates = pagination.items
        
    except Exception as e:
        logger.error(f"Explorer certificados error: {e}")
        certificates = []
        pagination = None
        search = ''
    
    return render_template(
        'explorer/certificados.html',
        certificates=certificates,
        pagination=pagination,
        search=search
    )


@explorer_bp.route('/certificado/<hash_cert>')
def certificado_detalle(hash_cert):
    """Detail view for a single certificate"""
    try:
        from models import PoServValidation, User
        
        cert = PoServValidation.query.filter_by(hash_certificado=hash_cert).first()
        if not cert:
            cert = PoServValidation.query.filter_by(codigo_validacion=hash_cert).first()
        
        if not cert:
            abort(404)
        
        tecnico = User.query.get(cert.tecnico_id) if cert.tecnico_id else None
        cliente = User.query.get(cert.cliente_id) if cert.cliente_id else None
        
    except Exception as e:
        logger.error(f"Explorer certificado detalle error: {e}")
        abort(500)
    
    return render_template(
        'explorer/certificado_detalle.html',
        cert=cert,
        tecnico=tecnico,
        cliente=cliente,
        psp_per_transaction=TOTAL_PSP_PER_TRANSACTION,
        wallets=GREEK_WALLETS
    )


@explorer_bp.route('/propiedades')
def propiedades():
    """List all PropertyNFT records"""
    try:
        from models import PropertyNFT, PropertyLocation
        
        page = request.args.get('page', 1, type=int)
        per_page = 20
        search = request.args.get('search', '')
        
        query = PropertyNFT.query.order_by(PropertyNFT.id.desc())
        
        if search:
            query = query.join(PropertyLocation).filter(
                PropertyLocation.normalized_address.ilike(f'%{search}%')
            )
        
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        properties = pagination.items
        
    except Exception as e:
        logger.error(f"Explorer propiedades error: {e}")
        properties = []
        pagination = None
        search = ''
    
    return render_template(
        'explorer/propiedades.html',
        properties=properties,
        pagination=pagination,
        search=search
    )


@explorer_bp.route('/propiedad/<int:prop_id>')
def propiedad_detalle(prop_id):
    """Detail view for a PropertyNFT"""
    try:
        from models import PropertyNFT, PropertyOwnership, PropertyCertificate, PoServValidation
        
        prop = PropertyNFT.query.get_or_404(prop_id)
        
        owners = PropertyOwnership.query.filter_by(
            property_nft_id=prop_id
        ).order_by(PropertyOwnership.started_at.desc()).all()
        
        prop_certs = PropertyCertificate.query.filter_by(
            property_nft_id=prop_id
        ).all()
        cert_ids = [pc.poserv_validation_id for pc in prop_certs]
        certificates = PoServValidation.query.filter(
            PoServValidation.id.in_(cert_ids)
        ).order_by(PoServValidation.fecha_validacion.desc()).all() if cert_ids else []
        
    except Exception as e:
        logger.error(f"Explorer propiedad detalle error: {e}")
        abort(500)
    
    return render_template(
        'explorer/propiedad_detalle.html',
        prop=prop,
        owners=owners,
        certificates=certificates
    )


@explorer_bp.route('/emision')
def emision():
    """PSP Token emission history"""
    try:
        from models import PoServValidation
        
        total_certificates = PoServValidation.query.count()
        total_psp = total_certificates * TOTAL_PSP_PER_TRANSACTION
        
        recent_emissions = PoServValidation.query.order_by(
            PoServValidation.fecha_validacion.desc()
        ).limit(50).all()
        
        distribution = get_distribution_summary()
        
    except Exception as e:
        logger.error(f"Explorer emision error: {e}")
        total_certificates = 0
        total_psp = 0
        recent_emissions = []
        distribution = {}
    
    return render_template(
        'explorer/emision.html',
        total_certificates=total_certificates,
        total_psp=total_psp,
        recent_emissions=recent_emissions,
        distribution=distribution,
        psp_per_transaction=TOTAL_PSP_PER_TRANSACTION,
        wallets=GREEK_WALLETS
    )


@explorer_bp.route('/buscar')
def buscar():
    """Global search across certificates and properties"""
    query = request.args.get('q', '')
    
    if not query:
        return render_template('explorer/buscar.html', results=None, query='')
    
    try:
        from models import PoServValidation, PropertyNFT, PropertyLocation
        
        certificates = PoServValidation.query.filter(
            (PoServValidation.hash_certificado.ilike(f'%{query}%')) |
            (PoServValidation.codigo_validacion.ilike(f'%{query}%'))
        ).limit(10).all()
        
        properties = PropertyNFT.query.join(PropertyLocation).filter(
            (PropertyLocation.normalized_address.ilike(f'%{query}%')) |
            (PropertyNFT.token_code.ilike(f'%{query}%'))
        ).limit(10).all()
        
        results = {
            'certificates': certificates,
            'properties': properties
        }
        
    except Exception as e:
        logger.error(f"Explorer search error: {e}")
        results = {'certificates': [], 'properties': []}
    
    return render_template(
        'explorer/buscar.html',
        results=results,
        query=query
    )


@explorer_bp.route('/workers')
def workers():
    """List all Workers with certificates"""
    try:
        from app import db
        from models import PoServValidation, User
        from sqlalchemy import func
        
        page = request.args.get('page', 1, type=int)
        per_page = 20
        search = request.args.get('search', '')
        
        subquery = db.session.query(
            PoServValidation.tecnico_id,
            func.count(PoServValidation.id).label('total_certs'),
            func.coalesce(func.sum(PoServValidation.valor_servicio_usd), 0).label('total_usd')
        ).filter(
            PoServValidation.tecnico_id.isnot(None)
        ).group_by(PoServValidation.tecnico_id).subquery()
        
        query = User.query.join(
            subquery, User.id == subquery.c.tecnico_id
        ).add_columns(
            subquery.c.total_certs,
            subquery.c.total_usd
        ).order_by(subquery.c.total_certs.desc())
        
        if search:
            query = query.filter(User.name.ilike(f'%{search}%'))
        
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        workers_list = pagination.items
        
    except Exception as e:
        logger.error(f"Explorer workers error: {e}")
        workers_list = []
        pagination = None
        search = ''
    
    return render_template(
        'explorer/workers.html',
        workers=workers_list,
        pagination=pagination,
        search=search,
        psp_per_transaction=TOTAL_PSP_PER_TRANSACTION
    )


@explorer_bp.route('/worker/<int:worker_id>')
def worker_detalle(worker_id):
    """Detail view for a Worker"""
    try:
        from models import PoServValidation, User
        
        worker = User.query.get_or_404(worker_id)
        
        certificates = PoServValidation.query.filter_by(
            tecnico_id=worker_id
        ).order_by(PoServValidation.fecha_validacion.desc()).all()
        
        total_certs = len(certificates)
        total_psp = total_certs * TOTAL_PSP_PER_TRANSACTION
        total_usd = sum(c.valor_servicio_usd or 0 for c in certificates)
        
    except Exception as e:
        logger.error(f"Explorer worker detalle error: {e}")
        abort(500)
    
    return render_template(
        'explorer/worker_detalle.html',
        worker=worker,
        certificates=certificates,
        total_certs=total_certs,
        total_psp=total_psp,
        total_usd=total_usd,
        psp_per_transaction=TOTAL_PSP_PER_TRANSACTION
    )


@explorer_bp.route('/stats')
def stats():
    """PSP Protocol Statistics"""
    try:
        from app import db
        from models import PoServValidation, PropertyNFT
        from sqlalchemy import func
        
        total_certificates = PoServValidation.query.count()
        total_psp = total_certificates * TOTAL_PSP_PER_TRANSACTION
        
        total_workers = db.session.query(
            func.count(func.distinct(PoServValidation.tecnico_id))
        ).filter(PoServValidation.tecnico_id.isnot(None)).scalar() or 0
        
        total_properties = PropertyNFT.query.count()
        
        distribution = get_distribution_summary()
        
    except Exception as e:
        logger.error(f"Explorer stats error: {e}")
        total_certificates = 0
        total_psp = 0
        total_workers = 0
        total_properties = 0
        distribution = {}
    
    return render_template(
        'explorer/stats.html',
        total_certificates=total_certificates,
        total_psp=total_psp,
        total_workers=total_workers,
        total_properties=total_properties,
        distribution=distribution,
        psp_per_transaction=TOTAL_PSP_PER_TRANSACTION,
        wallets=GREEK_WALLETS
    )
