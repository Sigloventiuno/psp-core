# PSP Explorer - Public Ledger Viewer

> **PSP Explorer is a read-only visualization tool.**
> **It does not emit tokens, modify data, or perform any commercial operations.**

> **Multiple independent PSP Explorers may exist.**
> **This repository represents one possible implementation.**

## Overview

PSP Explorer provides an Etherscan-style interface for viewing PSP Protocol data:

- **Certificates**: Browse and search PoServ validation certificates
- **Properties**: View PropertyNFT records with service history
- **Workers**: See worker statistics and completed services
- **Emission**: Track PSP token emission history
- **Statistics**: Protocol-wide statistics and distribution

## Features

| Feature | Description | Type |
|---------|-------------|------|
| Certificate List | Paginated list of all PoServ certificates | Read |
| Certificate Detail | Full certificate info with hash verification | Read |
| Property Browser | List and search PropertyNFTs | Read |
| Property Detail | Service history and PSP accumulation | Read |
| Worker List | Ranked by completed certificates | Read |
| Worker Detail | Individual worker statistics | Read |
| Global Search | Search across certificates and properties | Read |
| Statistics | Protocol-wide metrics | Read |

## What This Module Does NOT Do

- **Does NOT emit PSV certificates**
- **Does NOT modify any data**
- **Does NOT authenticate users commercially**
- **Does NOT process payments**
- **Does NOT contain business logic**

## Dependencies

- `psp_core`: Protocol constants and distribution rules
- `Flask`: Web framework (read-only routes)
- Database access: Read-only queries to view data

## Routes

| Route | Description |
|-------|-------------|
| `/explorer/` | Homepage with overview |
| `/explorer/certificados` | Certificate list |
| `/explorer/certificado/<hash>` | Certificate detail |
| `/explorer/propiedades` | Property list |
| `/explorer/propiedad/<id>` | Property detail |
| `/explorer/workers` | Worker list |
| `/explorer/worker/<id>` | Worker detail |
| `/explorer/emision` | Emission history |
| `/explorer/stats` | Protocol statistics |
| `/explorer/buscar` | Global search |

## License

Apache License 2.0 - See [LICENSE](LICENSE) file.

---

> **This module is intended for public data visualization only.**
> **It consumes data from PSP Protocol but does not control or modify it.**
